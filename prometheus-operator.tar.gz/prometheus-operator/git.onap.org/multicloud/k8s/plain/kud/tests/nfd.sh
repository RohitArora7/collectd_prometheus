#!/bin/bash
# SPDX-license-identifier: Apache-2.0
##############################################################################
# Copyright (c) 2018
# All rights reserved. This program and the accompanying materials
# are made available under the terms of the Apache License, Version 2.0
# which accompanies this distribution, and is available at
# http://www.apache.org/licenses/LICENSE-2.0
##############################################################################

set -o errexit
set -o nounset
set -o pipefail

source _common_test.sh
source _functions.sh

rm -f $HOME/*.yaml
pod_name=nfd-pod

install_deps

function create_pod_yaml_with_affinity {

cat << POD > $HOME/$pod_name-affinity.yaml
apiVersion: v1
kind: Pod
metadata:
  name: $pod_name
spec:
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
        - matchExpressions:
          - key: "feature.node.kubernetes.io/kernel-version.major"
            operator: Gt
            values:
            - '3'
        - matchExpressions:
          - key: "feature.node.kubernetes.io/kernel-version.major"
            operator: Lt
            values:
            - '20'
        - matchExpressions:
          - key: "feature.node.kubernetes.io/kernel-version.major"
            operator: In
            values:
            - '3'
            - '4'
            - '5'
        - matchExpressions:
          - key: "feature.node.kubernetes.io/kernel-version.major"
            operator: NotIn
            values:
            - '1'
        - matchExpressions:
          - key: "feature.node.kubernetes.io/kernel-version.major"
            operator: Exists
        - matchExpressions:
          - key: "feature.node.kubernetes.io/label_does_not_exist"
            operator: DoesNotExist
  containers:
  - name: with-node-affinity
    image: gcr.io/google_containers/pause:2.0
POD
}

function create_pod_yaml_with_nodeSelector {
    # Get the major kernel version of a worker node in the cluster:
    # this will be used below in the node selector of the test pod
    local -r node_name=$(kubectl get nodes -o jsonpath='{range .items[*]}{.metadata.name} {.spec.taints[?(@.effect=="NoSchedule")].effect}{"\n"}{end}' | awk 'NF==1 {print $0;exit}')
    local -r kernel_version=$(kubectl get node ${node_name} -o jsonpath='{.metadata.labels.feature\.node\.kubernetes\.io/kernel-version\.major}')

    cat << POD > $HOME/$pod_name-nodeSelector.yaml
apiVersion: v1
kind: Pod
metadata:
  name: ${pod_name}
spec:
  nodeSelector:
    feature.node.kubernetes.io/kernel-version.major: '${kernel_version}'
  containers:
  - name: with-node-affinity
    image: gcr.io/google_containers/pause:2.0
POD

}

if $(kubectl version &>/dev/null); then
    labels=$(kubectl get nodes -o json | jq .items[].metadata.labels)

    echo $labels
    if [[ $labels != *"kubernetes.io"* ]]; then
        exit 1
    fi

    create_pod_yaml_with_affinity
    create_pod_yaml_with_nodeSelector

    for podType in ${POD_TYPE:-nodeSelector affinity}; do

        kubectl delete pod $pod_name --ignore-not-found=true --now
        while kubectl get pod $pod_name &>/dev/null; do
            sleep 5
        done

        kubectl create -f $HOME/$pod_name-$podType.yaml --validate=false

        for pod in $pod_name; do
            wait_for_pod $pod
        done
        kubectl delete pod $pod_name
        while kubectl get pod $pod_name &>/dev/null; do
            sleep 5
        done

    done
fi

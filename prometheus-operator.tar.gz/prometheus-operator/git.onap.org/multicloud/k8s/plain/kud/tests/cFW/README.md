# Firewall Cloud-Native Network Function Demo

This is the implementation of the ONAP vFirewall use case as
Cloud-Native Network Function.

## License

Apache-2.0
